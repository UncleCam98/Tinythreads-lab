/*
    Part of the Real-Time Embedded Systems course at Halmstad University
    Copyright (c) 2017, Sebastian Kunze <sebastian.kunze@hh.se>
    All rights reserved.
*/
/*
 * Modified by Wagner Morais on Aug 2023.
*/
#include <stdio.h>
#include "lib/rpi-systimer.h"
#include "lib/expstruct.h"
#include "lib/piface.h"
#include "lib/led.h"
#include <stdlib.h>

#define LINE 32

int main()
{
	char str[LINE];
	led_init();
	piface_puts("DT8025 - A2P3");
	RPI_WaitMicroSeconds(2000000);	
	piface_clear();
	
    ExpStruct* value;
  
    int i = 1; 
	// cyclic execution
    while (1) {
		if (i > 20){
			i = 1;
		}
		value = iexp(i);
		piface_clear();
		sprintf(str,"%d:%d.%02d\n", i, value->expInt, value->expFraction);
		piface_puts(str);		
		i++;
		free(value);
    }
	return 0;
}
