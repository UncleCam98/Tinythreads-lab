//  Created by Mohammadreza Mousavi [mohmou] on 9/5/14.
//  Updated by Masoumeh Taromirad on 11/08/16.
//  Updated by Wagner Morais and Johannes van Esch on 28/08/18.
//  Copyright (c) 2014 by Mohammadreza Mousavi [mohmou]. All rights reserved.

#ifndef lab0_iregister_h
#define lab0_iregister_h

/**
 *  iRegister
 *  An iRegister is a structure which represents an 32-bit register and
 *  is equipped with standard operations to modify and display them.
 */ 
typedef struct{
    int content;
} iRegister;


#define EMPTY 0x00000000
#define ALL_BITS_SET (int) 0xFFFFFFFF
#define FIRST_NIBBLE_SET 0xF

/**
 *  Below you find the declarations for the functions to modify and display the
 *  memory content of a iRegister data structure. Before each declaration, a brief 
 *  description about what the function shall do is given. 
 *  Later in this file, the documentation for the resetBit function is given. 
 *  Students should follow that format.
 */ 

/** @brief resets all the bits of the iRegister (to 0)*
 * 
 *  @param r A pointer to a memory location of a iRegister data structure.
 * 
 *  @return void
 * 
 *  Pre-condition: iRegister != Null
 * 
 *  Post-condition: after resetAll(*r) all the bits is set to 0, assure all the bits is set to 0 by 
 *  assuring all the bits is set to 0 by if((r->content | 0x00000000) == 1).
 * 
 *  test-cases: 
 *  first do setBit(i ,&r) with 1-2 bits,
 *  then do resetAll(&r),
 *  display the result by 
 *  printf("%s",reg2str(r)) 
 */ 
void resetAll(iRegister *);

/** @brief set the specific bit of the iRegister (to 1)*
 * 
 *  @param i A int to a index of the bit to set
 * 
 *  @param r A pointer to a memory location of a iRegister data structure.
 * 
 *  @return void
 * 
 *  Pre-condition: 0 > i > 31 and iRegister != Null
 * 
 *  Post-condition: after setBit(i, &r) the specific bit on index i is set to 1
 *  properties: 
 *  after setBit(i, &r),  getBit(i, r) = 1
 *  if getBit(i, r) == 0 then  
 *     "Error: Failed to set Bit" is printed
 * 
 *  test-cases:
 *  first do resetAll(&r), 
 *  then do setBit(i ,&r) with 1-2 bits,
 *  display the result by 
 *  printf("%s",reg2str(r)) 
 */
void setBit(int, iRegister *);


/** @brief sets all the bits of the iRegister (to 1)
 * 
 *  @param r A pointer to a memory location of a iRegister data structure.
 * 
 *  @return void
 * 
 *  Pre-condition: iRegister != Null
 * 
 *  Post-condition: Assure all the bits is set to 1 by by if(r->content != ALL_BITS_SET).
 * 
 *  test-cases: 
 *  first do resetAll(&r),
 *  then do setAll(&r) with 1-2 bits,
 *  display the result by 
 *  printf("%s",reg2str(r)) 
 */
void setAll(iRegister *);


/** @brief returns the i'th bit of the iRegister as an integer (1 if it is set, or 0 otherwise)
 * 
 * @param i The bit position to retrieve (0 to 31).
 * 
 * @param r A pointer to a memory location of a iRegister data structure.
 * 
 * @return int
 * 
 *  Pre-condition: (i > 31 || i < 0) and iRegister != Null
 * 
 *  Post-condition:(r->content & (1 << i)) == 0)
 *  properties: if getBit(i, r) == 0 then return 0 otherwise return 1
 * 
 *  test-cases: 
 *  first do resetAll(&r),
 *  then do setBit(1, &r),
 *  then do getBit(1, &r),
 *  display the result by 
 *  printf("%d",getBit(1, &r)) 
 */
int getBit(int, iRegister *);


/** @brief set the first (for pos=1) or the second (for pos=2) four bits of iRegister
 * 
 * @param pos The nibble position to retrieve (1 for the first nibble, 2 for the second nibble).
 * 
 * @param value The 4-bit value (0 to 15) to be assigned to the nibble.
 * 
 * @param r A pointer to a memory location of a iRegister data structure.
 * 
 * @return void
 * 
 * Pre-condition: (pos > 8 || pos < 1), ((value > 15) || (value < 0)) and iRegister != Null
 * 
 * Post-condition: After assignNibble(pos, value, r) controll that only the 4-bits in the specific nibble has changed. 
 * properties: Move the content to the first Nibble and check if the value is the same as the inserted value with (((r->content >> (4 * pos)) & 0xF) != value)
 * 
 *  test-cases: 
 *  first do resetAll(&r),
 *  then do assignNibble(1, 2, &r),
 *  display the result by 
 *  printf("%s",reg2str(r)) 
 */
void assignNibble(int, int, iRegister *);


/** @brief get the first (for pos=1) or the second (for pos=2) four bits of iRegister
 * @param pos The nibble position to retrieve (1 for the first nibble, 2 for the second nibble).
 * 
 * @param r A pointer to a memory location of a iRegister data structure.
 * 
 * @return int
 * 
 * Pre-condition: (pos > 8 || pos < 1) and iRegister != Null
 * 
 * Post-condition:(tempValue < 0 || tempValue > 0xF) to check if the returned value is a valid Nibble (0-15)
 *  (tempValue != extractedNibble) to check if the returned value match the expected value from the register.
 * 
 *  test-cases: 
 *  first do resetAll(&r),
 *  then do assignNibble(1, 2, &r),
 *  then do getNibble(1, &r),
 *  display the result by 
 *  printf("%d", getNibble(1, &r)) 
 */
int getNibble(int, iRegister *);


/** @brief returns a pointer to an array of 32 characters, with each character 
 *  representing the corresponding bit of the iRegister, i.e., if the bit is set,
 *  then the character is "1" (ASCII char with code 49), or otherwise is "0" 
 *  (ASCII char with code 48)
 * NOTE: return char* needs to be free'd
 * 
 * @param r a iRegister data structure.
 * 
 * @return char*
 * 
 * Pre-condition: iRegister != Null
 * 
 * Post-condition: (str[32] != '\0') to control that the last character in the array a null-terminator.
 */
char *reg2str(iRegister);


/** @brief shifts all the bits of the iRegister to the right by n places (appends 0 
 *  from the left)
 * 
 * @param r A pointer to a memory location of a iRegister data structure.
 * 
 * @param n The number of bit positions to shift.
 * 
 * @return void
 * 
 * Pre-condition: iRegister != Null
 * 
 * Pro-condition: (temp == 1 && getBit(31, r) == 0) to check if the last bit is 1 or 0 before it was shifted.
 * ((oldContent >> n) != r->content) to check if the temporary content is the same value
 * as the content in the register after shifting n places.
 * 
 *  test-cases: 
 *  first do resetAll(&r),
 *  then do assignNibble(2, 1, &r),
 *  then do setBit(31, &r),
 *  then do shiftRight(1, &r),
 *  display the result by 
 *  printf("%s",reg2str(r))  
 */
void shiftRight(int, iRegister *);


/** @brief shifts all the bits of the iRegister to the left by n places (appends 0 
 *  from the right)
 * 
 * @param r A pointer to a memory location of a iRegister data structure.
 * 
 * @param n The number of bit positions to shift.
 * 
 * @return void
 * 
 * Pre-condition: iRegister != Null and temp = getBit(31, r)
 * 
 * Pro-condition: ((oldContent >> n) != r->content) to check if the temporary content is the same value
 * as the content in the register after shifting n places.
 * 
 *  test-cases: 
 *  first do resetAll(&r),
 *  then do assignNibble(2, 1, &r),
 *  then do shiftLeft(1, &r),
 *  display the result by 
 *  printf("%s",reg2str(r))
 */
void shiftLeft(int, iRegister *);


/** @brief Resets the i'th bit of the iRegister (to 0)
 *
 *  @param i Is i'th bit of the iRegister to be reset
 * 
 *  @param r A pointer to a memory location of a iRegister data structure.
 * 
 *  @return void
 * 
 *  Pre-condition: 0 <= i < 32 and iRegister != Null
 * 
 *  Post-condition: after reset(i, r) the i'th bit of iRegister is 0, all other 
 *  bits remain unchanged
 *  properties: 
 *  after resetBit(i, r),  getBit(i, r) = 0
 *  if getBit(i, r) == 0 then  
 *    getBit(j, r) returns the same value for all 
 *  0 <= j < 32 and j <> i before and after resetBit(i, r)
 * 
 *  test-cases: 
 *  1,2,3. Allocate memory to an iRegister r
 *  first do resetAll(&r),
 *  then set the i'th bit of &x by setBit(i, &r) for i = 0, 15 and 23 and then
 *  display the result after each and every call by 
 *    printf("%s",reg2str(r)) 
 */
void resetBit(int, iRegister *);

#endif
