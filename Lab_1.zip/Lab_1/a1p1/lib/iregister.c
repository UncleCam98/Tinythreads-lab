//  Created by Mohammadreza Mousavi [mohmou] on 9/5/14.
//  Updated by Masoumeh Taromirad on 11/08/16.
//  Updated by Wagner Morais and Johannes van Esch on 28/08/18.
//  Updated by Wagner Morais and Hazem Ali on 26/08/21.
//  Copyright (c) 2014 by Mohammadreza Mousavi [mohmou]. All rights reserved.

#include "iregister.h"
#include <stdio.h>
#include <stdlib.h>

void resetBit(int i, iRegister *r) {
  // pre-condition
  if (r == NULL) {
    fprintf(stderr, "Error: A NULL pointer was given to resetBit\n");
    return;
  }
  // pre-condition
  if (i < 0 || i > 31) {
    fprintf(stderr, "Error: Invalid bit\n");
    return;
  }

  r->content &= ~(1 << i);

  // post-condition
  if ((r->content & (1 << i)) != 0) {
    fprintf(stderr, "Error: Failed to reset Bit\n");
    return;
  }
}

void resetAll(iRegister *r) {
  // pre-condition
  if (r == NULL) {
    fprintf(stderr, "Error: A NULL pointer was given to resetAll\n");
    return;
  }

  r->content = EMPTY;

  // post-condition
  if ((r->content | EMPTY) == 1) {
    fprintf(stderr, "Error: Failed to reset all Bits! \n");
    return;
  }
}

void setBit(int i, iRegister *r) {
  // pre-condition
  if (r == NULL) {
    fprintf(stderr, "Error: A NULL pointer was given to setBit\n");
    return;
  }

  // pre-condition
  if (i > 31 || i < 0) {
    fprintf(stderr, "Error: i is out of range! [0,31]\n");
    return;
  }

  r->content |= (1 << i);

  // post-condition
  if ((r->content & (1 << i)) == 0) {
    fprintf(stderr, "Error: Failed to set Bit \n");
    return;
  }
}

void setAll(iRegister *r) {
  // pre-condition
  if (r == NULL) {
    fprintf(stderr, "Error: A NULL pointer was given to setAll\n");
    return;
  }

  r->content = ALL_BITS_SET;

  // post-condition
  if (r->content != ALL_BITS_SET) {
    fprintf(stderr, "Error: Failed to set all Bits! \n");
    return;
  }
}

int getBit(int i, iRegister *r) {

  // pre-condition
  if (r == NULL) {
    fprintf(stderr, "Error: A NULL pointer was given to getBit\n");
    return -1;
  }

  // pre-condition
  if (i > 31 || i < 0) {
    fprintf(stderr, "Error: i is out of range! [0,31]\n");
    return -2;
  }

  if ((r->content & (1 << i)) == 0) {
    return 0;
  } else {
    return 1;
  }
}

void assignNibble(int pos, int value, iRegister *r) {
  // pre-condition
  if (r == NULL) {
    fprintf(stderr, "Error: A NULL pointer was given to assignNibble\n");
    return;
  }

  // pre-condition
  if (pos > 8 || pos < 1) {
    fprintf(stderr, "Error: The position doesn't exist in assignNibble\n");
    return;
  }

  //pre-condition
  if((value > 15) || (value < 0)){
    fprintf(stderr, "Error: The value is out of range in assignNibble\n");
    return;
  }

  --pos;
  int temp = (FIRST_NIBBLE_SET) << (4 * pos);
  r->content &= ~temp;
  r->content |= (value & FIRST_NIBBLE_SET) << (4 * pos);


  //post-condition
  if(((r->content >> (4 * pos)) & 0xF) != value) {
    fprintf(stderr, "Error: Nibble assignment did not work as expected.\n");
  }
}

int getNibble(int pos, iRegister *r) {
  // pre-condition
  if(r == NULL){
    fprintf(stderr, "Error: A NULL pointer was given to getNibble\n");
    return -1;
  }

  // pre-condition
  if (pos > 8 || pos < 1) {
    fprintf(stderr, "Error: The position doesn't exist in getNibble\n");
    return -1;
  }
  
  --pos;
  int temp = (FIRST_NIBBLE_SET) << (4 * pos);
  int tempValue = r->content;
  tempValue &= temp;
  tempValue >>= (4 * pos);
  // post-condition
  if (tempValue < 0 || tempValue > 0xF) {
    fprintf(stderr, "Error: Returned value is not a valid nibble\n");
  }

  // post-condition
  int extractedNibble = (r->content >> (4 * pos)) & 0xF;
  if (tempValue != extractedNibble) {
    fprintf(stderr, "Error: Extracted nibble does not match the expected value "
                    "from the register\n");
  }

  return tempValue;
}

char *reg2str(iRegister r) {
  char *str = (char *)calloc(33, sizeof(char));

  if(str == NULL){
    fprintf(stderr, "Error: Calloc failed for variable str in reg2str\n");
  }

  for (int i = 31, j = 0; i >= 0; i--, j++) {
    if (getBit(i, &r)) {
      str[j] = '1';
      continue;
    }
    str[j] = '0';
  }
  str[32] = '\0';

  //post-condition
  if (str[32] != '\0') { 
    fprintf(stderr, "Error: String is not null-terminated properly.\n");
    }
  return str;
}

void shiftRight(int n, iRegister *r) {

  // pre-condition
  if (r == NULL) {
    fprintf(stderr, "Error: A NULL pointer was given to shiftRight\n");
    return;
  }

  int temp = getBit(31, r);
  int oldContent = r->content;

  r->content = r->content >> n;

  // post-condition
  if(temp == 1 && getBit(31, r) == 0){
    setBit(31, r);
  }

   // post-condition
  if ((oldContent >> n) != r->content) {
        fprintf(stderr, "Error: shiftRight did not occur as expected.\n");
    }
}

void shiftLeft(int n, iRegister *r) {

  // pre-condition
  if (r == NULL) {
    fprintf(stderr, "Error: A NULL pointer was given to shiftLeft\n");
    return;
  }
  
  int oldContent = r->content;
  r->content = r->content << n;

   // post-condition
  if ((oldContent >> n) != r->content) {
        fprintf(stderr, "Error: shiftRight did not occur as expected.\n");
    }
}