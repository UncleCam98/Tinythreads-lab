/*
    Part of the Real-Time Embedded Systems course at Halmstad University
    Copyright (c) 2017, Sebastian Kunze <sebastian.kunze@hh.se>
    All rights reserved.
	Wagner de Morais (Wagner.deMorais@hh.se)
*/

#include <stdio.h>
#include "uart.h"
#include "iregister.h"
#include <stdlib.h>

#define LINE 80

void get_string(char* str){
	for(int i = 0; i < LINE; i++){
		str[i] = uart_getc();
		if(str[i] == '\n'){
			str[i+1] = '\0';
			break;
		}
	}
}

void display_number(int n){
	char buffer [12];
	sprintf(buffer, "%d", n);
	uart_puts(buffer);
}

int main()
{
	iRegister r;
	char str[LINE];
	char *reg;
	int inumber, inibble, ibit, ishift = 0;
	// Using the uart
	// First, initialize and clear the channel
	uart_init();
	uart_clear();

	uart_puts("Enter your name: ");
	get_string(str);
	uart_puts(str);

	uart_puts("Welcome " );
	uart_puts(str);

	uart_puts("Enter a integer number (32 bit): ");
	get_string(str);
	inumber = atoi(str);
	uart_puts(str);

	uart_puts("Enter the bit position (0<=bit<=31): ");
	get_string(str);
	ibit = atoi(str);
	uart_puts(str);
	
	uart_puts("Enter the nibble position (1<=bit<=8): ");
	get_string(str);
	inibble = atoi(str);
	uart_puts(str);

	uart_puts("Enter the number of bits to shift (1<=bit<=31): ");
	get_string(str);
	ishift = atoi(str);
	uart_puts(str);

	r.content = inumber;

	uart_puts("You entered number ");
	display_number(inumber);
	uart_puts(" ");
	reg = reg2str(r);
	uart_puts(reg);
	free(reg);
	uart_puts("\n");

	uart_puts("Bit: ");
	display_number(ibit);
	uart_puts(", Nibble: ");
	display_number(inibble);
	uart_puts("\n");

	setAll(&r);
	uart_puts("setAll(&r) returned ");
	display_number(r.content);
	uart_puts(" ");
	reg = reg2str(r);
	uart_puts(reg);
	free(reg);
	uart_puts("\n");

	resetAll(&r);
	uart_puts("resetAll(&r) returned ");
	display_number(r.content);
	uart_puts(" ");
	reg = reg2str(r);
	uart_puts(reg);
	free(reg);
	uart_puts("\n");

	setBit(ibit, &r);
	uart_puts("setBit(");
	display_number(ibit);
	uart_puts(", &r) returned ");
	display_number(r.content);
	uart_puts(" ");
	reg = reg2str(r);
	uart_puts(reg);
	free(reg);
	uart_puts("\n");

	uart_puts("getBit(");
	display_number(ibit);
	uart_puts(", &r) returned ");
	display_number(getBit(1, &r));
	uart_puts("\n");

	resetBit(ibit, &r);
	uart_puts("resetBit(");
	display_number(ibit);
	uart_puts(", &r) returned ");
	display_number(r.content);
	uart_puts(" ");
	reg = reg2str(r);
	uart_puts(reg);
	free(reg);
	uart_puts("\n");

	assignNibble(inibble, ibit, &r);
	uart_puts("assignNibble(");
	display_number(inibble);
	uart_puts(", ");
	display_number(ibit);
	uart_puts(", &r) returned ");
	display_number(r.content);
	uart_puts(" ");
	reg = reg2str(r);
	uart_puts(reg);
	free(reg);
	uart_puts("\n");

	uart_puts("getNibble(");
	display_number(inibble);
	uart_puts(", &r) returned ");
	display_number(getNibble(inibble, &r));
	uart_puts(" ");
	reg = reg2str(r);
	uart_puts(reg);
	free(reg);
	uart_puts("\n");

	shiftRight(ishift, &r);
	uart_puts("shiftRight(");
	display_number(ishift);
	uart_puts(", &r) returned ");
	display_number(r.content);
	uart_puts(" ");
	reg = reg2str(r);
	uart_puts(reg);
	free(reg);
	uart_puts("\n");

	shiftLeft(ishift, &r);
	uart_puts("shiftLeft(");
	display_number(ishift);
	uart_puts(", &r) returned ");
	display_number(r.content);
	uart_puts(" ");
	reg = reg2str(r);
	uart_puts(reg);
	free(reg);
	uart_puts("\n");
	

	
	// To Display a string
	//uart_puts("String\n");
	
	// To get one character
	//c = uart_getc();
	
	// However, to get a number, you need to call uart_getc 
	// multiple times until receiving a new line.
	// The results of each call to uart_getc can be stored into str
	//atoi(str); //will result a number.

}